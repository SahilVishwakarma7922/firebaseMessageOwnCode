package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NotificationTest1Application {

	public static void main(String[] args) {
		SpringApplication.run(NotificationTest1Application.class, args);
	}

}
